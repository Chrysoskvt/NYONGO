"""
Application Nyongo - Pret entre particuliers RDC
Point d'entree principal
"""
from app.main import create_app

app = create_app()

if __name__ == '__main__':
    print("=" * 60)
    print("  NYONGO - Application de Pret entre Particuliers")
    print("  Demarrage du serveur sur http://127.0.0.1:5000")
    print("  Login par defaut: admin / admin123")
    print("=" * 60)
    app.run(debug=True, host='127.0.0.1', port=5000)
