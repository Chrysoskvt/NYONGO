import os
import json
from datetime import datetime, date, timedelta
from flask import (render_template, request, redirect, url_for, 
                    flash, jsonify, send_file, session)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from .models import db, Client, Pret, Paiement, Utilisateur
from .config import DB_PATH, UPLOAD_FOLDER


def format_montant(montant, devise='USD'):
    """Formater un montant avec le symbole de la devise"""
    if devise == 'USD':
        return f"{montant:,.2f} $"
    elif devise == 'CDF':
        return f"{montant:,.2f} FC"
    return f"{montant:,.2f} {devise}"


def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def enregistrer_routes(app):
    """Enregistrer toutes les routes de l'application"""
    
    @app.route('/')
    @login_required
    def index():
        """Tableau de bord principal"""
        total_clients = Client.query.count()
        total_prets = Pret.query.count()
        
        # Montant Total = montant pret + gain Nyongo (CONVENTION)
        montant_total_prets = sum(p.montant_avec_gain for p in Pret.query.all())
        
        total_paye = sum(
            sum(pa.montant for pa in p.paiements) 
            for p in Pret.query.all()
        )
        
        reste_a_recouvrer = montant_total_prets - total_paye
        
        prets_en_cours = Pret.query.filter_by(statut='En cours').count()
        prets_termine = Pret.query.filter_by(statut='Termine').count()
        
        # Derniers prets
        derniers_prets = Pret.query.order_by(Pret.date_creation.desc()).limit(5).all()
        
        # Derniers paiements
        derniers_paiements = Paiement.query.order_by(
            Paiement.date_creation.desc()).limit(5).all()
        
        stats = {
            'total_clients': total_clients,
            'total_prets': total_prets,
            'montant_total_prets': montant_total_prets,
            'total_paye': total_paye,
            'reste_a_recouvrer': reste_a_recouvrer,
            'prets_en_cours': prets_en_cours,
            'prets_termine': prets_termine,
        }
        
        return render_template('index.html', 
                               stats=stats, 
                               derniers_prets=derniers_prets,
                               derniers_paiements=derniers_paiements,
                               format_montant=format_montant)
    
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            user = Utilisateur.query.filter_by(nom_utilisateur=username).first()
            if user and check_password_hash(user.mot_de_passe, password):
                session['user_id'] = user.id
                session['user_name'] = user.nom_complet
                flash('Connexion reussie !', 'success')
                return redirect(url_for('index'))
            flash('Identifiants incorrects', 'danger')
        return render_template('login.html')
    
    @app.route('/logout')
    def logout():
        session.clear()
        flash('Deconnexion reussie', 'success')
        return redirect(url_for('login'))
    
    # ===================== CLIENTS =====================
    
    @app.route('/clients')
    @login_required
    def clients():
        liste_clients = Client.query.order_by(Client.date_creation.desc()).all()
        return render_template('clients.html', clients=liste_clients,
                               format_montant=format_montant)
    
    @app.route('/clients/ajouter', methods=['GET', 'POST'])
    @login_required
    def ajouter_client():
        if request.method == 'POST':
            nom = request.form.get('nom')
            telephone = request.form.get('telephone')
            adresse = request.form.get('adresse')
            numero_piece = request.form.get('numero_piece')
            type_piece = request.form.get('type_piece', 'Carte d\'identite')
            
            client = Client(
                nom=nom,
                telephone=telephone,
                adresse=adresse,
                numero_piece=numero_piece,
                type_piece=type_piece
            )
            db.session.add(client)
            db.session.commit()
            flash(f'Client {nom} ajoute avec succes !', 'success')
            return redirect(url_for('clients'))
        
        return render_template('client_form.html')
    
    @app.route('/clients/<int:id>')
    @login_required
    def detail_client(id):
        client = Client.query.get_or_404(id)
        return render_template('client_detail.html', client=client,
                               format_montant=format_montant)
    
    @app.route('/clients/<int:id>/modifier', methods=['GET', 'POST'])
    @login_required
    def modifier_client(id):
        client = Client.query.get_or_404(id)
        if request.method == 'POST':
            client.nom = request.form.get('nom', client.nom)
            client.telephone = request.form.get('telephone', client.telephone)
            client.adresse = request.form.get('adresse', client.adresse)
            client.numero_piece = request.form.get('numero_piece', client.numero_piece)
            client.type_piece = request.form.get('type_piece', client.type_piece)
            db.session.commit()
            flash('Client modifie avec succes !', 'success')
            return redirect(url_for('detail_client', id=client.id))
        return render_template('client_form.html', client=client)
    
    @app.route('/clients/<int:id>/supprimer', methods=['POST'])
    @login_required
    def supprimer_client(id):
        client = Client.query.get_or_404(id)
        if client.prets:
            flash('Impossible de supprimer un client avec des prets existants.', 'danger')
            return redirect(url_for('detail_client', id=id))
        db.session.delete(client)
        db.session.commit()
        flash('Client supprime.', 'success')
        return redirect(url_for('clients'))
    
    # ===================== PRETS =====================
    
    @app.route('/prets')
    @login_required
    def prets():
        liste_prets = Pret.query.order_by(Pret.date_creation.desc()).all()
        return render_template('loans.html', prets=liste_prets,
                               format_montant=format_montant)
    
    @app.route('/prets/ajouter', methods=['GET', 'POST'])
    @login_required
    def ajouter_pret():
        if request.method == 'POST':
            client_id = request.form.get('client_id')
            montant = float(request.form.get('montant', 0))
            devise = request.form.get('devise', 'USD')
            # Duree EXCLUSIVEMENT en semaines, saisie libre par l'utilisateur
            try:
                nombre_semaines = int(request.form.get('nombre_semaines', '').strip())
            except (TypeError, ValueError):
                nombre_semaines = 0
            if nombre_semaines < 1:
                flash('Veuillez saisir la duree du pret en semaines (nombre entier superieur a 0).', 'danger')
                clients = Client.query.order_by(Client.nom).all()
                return render_template('loan_form.html', clients=clients,
                                       aujourd_hui=date.today().strftime('%Y-%m-%d'))
            type_gain = request.form.get('type_gain', 'pourcentage')
            taux_gain = float(request.form.get('taux_gain', 10.0))
            montant_forfait = float(request.form.get('montant_forfait', 0))
            date_pret_str = request.form.get('date_pret')
            note = request.form.get('note', '')
            
            # Calcul du gain Nyongo selon la CONVENTION
            # Gain par semaine x nombre de semaines
            if type_gain == 'pourcentage':
                gain_hebdo = montant * (taux_gain / 100.0)
            else:
                gain_hebdo = montant_forfait
            
            gain_calcule = gain_hebdo * nombre_semaines
            
            montant_total = montant + gain_calcule
            
            code_pret = Pret.generer_code()
            
            date_pret = date.today()
            if date_pret_str:
                try:
                    date_pret = datetime.strptime(date_pret_str, '%Y-%m-%d').date()
                except ValueError:
                    pass
            
            pret = Pret(
                code_pret=code_pret,
                client_id=client_id,
                montant=montant,
                devise=devise,
                nombre_semaines=nombre_semaines,
                date_pret=date_pret,
                type_gain=type_gain,
                taux_gain=taux_gain,
                montant_forfait=montant_forfait,
                note=note
            )
            db.session.add(pret)
            db.session.commit()
            
            flash(f'Pret {code_pret} cree ! Montant: {format_montant(montant, devise)} + Gain Nyongo: {format_montant(gain_hebdo, devise)} x {nombre_semaines} semaines = {format_montant(gain_calcule, devise)} => Total: {format_montant(montant_total, devise)}', 'success')
            return redirect(url_for('detail_pret', id=pret.id))
        
        clients = Client.query.order_by(Client.nom).all()
        return render_template('loan_form.html', clients=clients,
                               aujourd_hui=date.today().strftime('%Y-%m-%d'))
    
    @app.route('/prets/<int:id>')
    @login_required
    def detail_pret(id):
        pret = Pret.query.get_or_404(id)
        return render_template('loan_detail.html', pret=pret,
                               format_montant=format_montant)
    
    @app.route('/prets/<int:id>/modifier', methods=['GET', 'POST'])
    @login_required
    def modifier_pret(id):
        pret = Pret.query.get_or_404(id)
        if request.method == 'POST':
            pret.montant = float(request.form.get('montant', pret.montant))
            pret.devise = request.form.get('devise', pret.devise)
            # Duree EXCLUSIVEMENT en semaines, saisie libre par l'utilisateur
            try:
                nouvelles_semaines = int(request.form.get('nombre_semaines', '').strip())
            except (TypeError, ValueError):
                nouvelles_semaines = 0
            if nouvelles_semaines < 1:
                flash('Veuillez saisir la duree du pret en semaines (nombre entier superieur a 0).', 'danger')
                clients = Client.query.order_by(Client.nom).all()
                return render_template('loan_form.html', pret=pret, clients=clients,
                                       aujourd_hui=pret.date_pret.strftime('%Y-%m-%d') if pret.date_pret else date.today().strftime('%Y-%m-%d'))
            pret.nombre_semaines = nouvelles_semaines
            
            # Mise a jour de la date de debut (la date de fin est recalculee automatiquement)
            date_pret_str = request.form.get('date_pret')
            if date_pret_str:
                try:
                    pret.date_pret = datetime.strptime(date_pret_str, '%Y-%m-%d').date()
                except ValueError:
                    pass
            pret.type_gain = request.form.get('type_gain', pret.type_gain)
            pret.taux_gain = float(request.form.get('taux_gain', pret.taux_gain))
            pret.montant_forfait = float(request.form.get('montant_forfait', pret.montant_forfait))
            pret.note = request.form.get('note', pret.note)
            
            statut = request.form.get('statut')
            if statut:
                pret.statut = statut
            
            db.session.commit()
            flash('Pret modifie avec succes !', 'success')
            return redirect(url_for('detail_pret', id=pret.id))
        
        clients = Client.query.order_by(Client.nom).all()
        return render_template('loan_form.html', pret=pret, clients=clients,
                               aujourd_hui=pret.date_pret.strftime('%Y-%m-%d') if pret.date_pret else date.today().strftime('%Y-%m-%d'))
    
    @app.route('/prets/<int:id>/supprimer', methods=['POST'])
    @login_required
    def supprimer_pret(id):
        pret = Pret.query.get_or_404(id)
        db.session.delete(pret)
        db.session.commit()
        flash('Pret supprime.', 'success')
        return redirect(url_for('prets'))
    
    # ===================== PAIEMENTS =====================
    
    @app.route('/prets/<int:pret_id>/paiement', methods=['GET', 'POST'])
    @login_required
    def ajouter_paiement(pret_id):
        pret = Pret.query.get_or_404(pret_id)
        if request.method == 'POST':
            montant = float(request.form.get('montant', 0))
            devise = request.form.get('devise', pret.devise)
            date_paiement_str = request.form.get('date_paiement')
            numero_semaine = request.form.get('numero_semaine', type=int)
            note = request.form.get('note', '')
            
            date_paiement = date.today()
            if date_paiement_str:
                try:
                    date_paiement = datetime.strptime(date_paiement_str, '%Y-%m-%d').date()
                except ValueError:
                    pass
            
            paiement = Paiement(
                pret_id=pret.id,
                montant=montant,
                devise=devise,
                date_paiement=date_paiement,
                numero_semaine=numero_semaine,
                note=note
            )
            db.session.add(paiement)
            
            # Verifier si le pret est termine
            if pret.montant_restant <= 0:
                pret.statut = 'Termine'
            
            db.session.commit()
            flash(f'Paiement de {format_montant(montant, devise)} enregistre !', 'success')
            return redirect(url_for('detail_pret', id=pret.id))
        
        return render_template('paiement_form.html', pret=pret,
                               format_montant=format_montant)
    
    @app.route('/prets/<int:pret_id>/paiement/<int:paiement_id>/supprimer', methods=['POST'])
    @login_required
    def supprimer_paiement(pret_id, paiement_id):
        paiement = Paiement.query.get_or_404(paiement_id)
        pret = Pret.query.get_or_404(pret_id)
        db.session.delete(paiement)
        
        # Re verifier le statut
        if pret.montant_restant > 0:
            pret.statut = 'En cours'
        
        db.session.commit()
        flash('Paiement supprime.', 'success')
        return redirect(url_for('detail_pret', id=pret_id))
    
    # ===================== PDF =====================
    
    @app.route('/prets/<int:id>/facture')
    @login_required
    def generer_facture(id):
        pret = Pret.query.get_or_404(id)
        from .utils.pdf_generator import generer_facture_pdf
        pdf_path = generer_facture_pdf(pret, app=app)
        return send_file(pdf_path, as_attachment=True,
                        download_name=f'facture_{pret.code_pret}.pdf')
    
    @app.route('/prets/<int:id>/amortissement')
    @login_required
    def generer_amortissement(id):
        pret = Pret.query.get_or_404(id)
        from .utils.pdf_generator import generer_tableau_amortissement_pdf
        pdf_path = generer_tableau_amortissement_pdf(pret, app=app)
        return send_file(pdf_path, as_attachment=True,
                        download_name=f'amortissement_{pret.code_pret}.pdf')
    
    # ===================== API =====================
    
    @app.route('/api/stats')
    def api_stats():
        """API statistiques"""
        montant_total_prets = sum(p.montant_avec_gain for p in Pret.query.all())
        total_paye = sum(
            sum(pa.montant for pa in p.paiements)
            for p in Pret.query.all()
        )
        
        return jsonify({
            'total_clients': Client.query.count(),
            'total_prets': Pret.query.count(),
            'montant_total_prets': montant_total_prets,
            'total_paye': total_paye,
            'reste_a_recouvrer': montant_total_prets - total_paye,
            'prets_en_cours': Pret.query.filter_by(statut='En cours').count(),
            'prets_termine': Pret.query.filter_by(statut='Termine').count(),
        })
