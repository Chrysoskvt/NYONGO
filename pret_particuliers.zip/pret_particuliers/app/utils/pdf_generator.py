import os
import io
from datetime import datetime, date, timedelta
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib.colors import HexColor, black, white
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Couleurs Nyongo
COULEUR_PRIMAIRE = HexColor('#1a5276')
COULEUR_SECONDAIRE = HexColor('#2ecc71')
COULEUR_ACCENT = HexColor('#e74c3c')
COULEUR_CLAIR = HexColor('#ecf0f1')
COULEUR_FONCE = HexColor('#2c3e50')


def _dessiner_en_tete(c, largeur, hauteur, pret=None):
    """Dessiner l'en-tete Nyongo"""
    # Bande superieure
    c.setFillColor(COULEUR_PRIMAIRE)
    c.rect(0, hauteur - 25*mm, largeur, 25*mm, fill=1, stroke=0)
    
    # Titre
    c.setFillColor(white)
    c.setFont('Helvetica-Bold', 18)
    c.drawString(20*mm, hauteur - 15*mm, 'NYONGO')
    c.setFont('Helvetica', 10)
    c.drawString(20*mm, hauteur - 20*mm, 'Pret Particuliers - RDC')
    
    # Date
    c.setFont('Helvetica', 9)
    c.drawRightString(largeur - 20*mm, hauteur - 15*mm, 
                      f'Date: {date.today().strftime("%d/%m/%Y")}')
    if pret:
        c.drawRightString(largeur - 20*mm, hauteur - 20*mm, 
                          f'Ref: {pret.code_pret}')


def _dessiner_pied_page(c, largeur, hauteur, page_num):
    """Dessiner le pied de page"""
    c.setFillColor(COULEUR_CLAIR)
    c.rect(0, 0, largeur, 15*mm, fill=1, stroke=0)
    c.setFillColor(COULEUR_FONCE)
    c.setFont('Helvetica', 7)
    c.drawString(20*mm, 8*mm, 'Nyongo - Pret Particuliers | Document confidentiel')
    c.drawRightString(largeur - 20*mm, 8*mm, f'Page {page_num}')


def _symbole_devise(devise):
    """Retourner le symbole de la devise"""
    if devise == 'USD':
        return '$'
    elif devise == 'CDF':
        return 'FC'
    return devise


def _formater_montant(montant, devise='USD'):
    """Formater un montant pour le PDF"""
    sym = _symbole_devise(devise)
    return f"{montant:,.2f} {sym}"


def generer_facture_pdf(pret, app=None):
    """Generer la facture/convention de pret en PDF"""
    from flask import current_app
    
    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), 'data', 'pdfs')
    os.makedirs(output_dir, exist_ok=True)
    
    pdf_path = os.path.join(output_dir, f'facture_{pret.code_pret}.pdf')
    
    c = canvas.Canvas(pdf_path, pagesize=A4)
    largeur, hauteur = A4
    
    page_num = 1
    _dessiner_en_tete(c, largeur, hauteur, pret)
    
    y = hauteur - 35*mm
    
    # Section Convention
    c.setFillColor(COULEUR_PRIMAIRE)
    c.setFont('Helvetica-Bold', 14)
    c.drawString(20*mm, y, 'CONVENTION DE PRET')
    y -= 10*mm
    
    # Informations client
    c.setFillColor(COULEUR_FONCE)
    c.setFont('Helvetica-Bold', 10)
    c.drawString(20*mm, y, 'INFORMATIONS DU CLIENT')
    y -= 7*mm
    
    c.setFont('Helvetica', 9)
    infos_client = [
        (f'Nom complet:', pret.client.nom),
        (f'Telephone:', pret.client.telephone or 'N/A'),
        (f'Adresse:', pret.client.adresse or 'N/A'),
        (f'Piece d\'identite:', f"{pret.client.type_piece} - {pret.client.numero_piece or 'N/A'}"),
    ]
    
    for label, valeur in infos_client:
        c.setFont('Helvetica-Bold', 9)
        c.drawString(25*mm, y, label)
        c.setFont('Helvetica', 9)
        c.drawString(75*mm, y, str(valeur))
        y -= 6*mm
    
    y -= 5*mm
    
    # Conditions du pret
    c.setFont('Helvetica-Bold', 10)
    c.drawString(20*mm, y, 'CONDITIONS DU PRET')
    y -= 7*mm
    
    c.setFont('Helvetica', 9)
    date_debut_txt = pret.date_debut.strftime('%d/%m/%Y') if pret.date_debut else 'N/A'
    date_fin_txt = pret.date_fin.strftime('%d/%m/%Y') if pret.date_fin else 'N/A'

    conditions = [
        ('Code du pret:', pret.code_pret),
        ('Date de debut:', date_debut_txt),
        ('Date de fin:', date_fin_txt),
        ('Duree:', f'{pret.nombre_semaines} semaines'),
        ('Montant du pret (capital):', _formater_montant(pret.montant, pret.devise)),
        ('Type de gain:', f"{'Pourcentage' if pret.type_gain == 'pourcentage' else 'Forfait'}"),
    ]
    
    if pret.type_gain == 'pourcentage':
        conditions.append(
            ('Taux du gain:', f'{pret.taux_gain}% par semaine')
        )
        conditions.append(
            ('Gain par semaine:', _formater_montant(pret.gain_hebdomadaire, pret.devise))
        )
        conditions.append(
            (f'Gain Nyongo total ({pret.nombre_semaines} sem.):',
             _formater_montant(pret.gain_total, pret.devise))
        )
    else:
        conditions.append(
            ('Forfait gain par semaine:', _formater_montant(pret.montant_forfait, pret.devise))
        )
        conditions.append(
            (f'Gain Nyongo total ({pret.nombre_semaines} sem.):',
             _formater_montant(pret.gain_total, pret.devise))
        )
    
    conditions.append(
        ('PRIX TOTAL (capital + gain):', _formater_montant(pret.montant_avec_gain, pret.devise))
    )
    conditions.append(
        ('Echeance hebdomadaire:', _formater_montant(pret.echeance_hebdomadaire, pret.devise))
    )
    
    for label, valeur in conditions:
        c.setFont('Helvetica-Bold', 9)
        c.drawString(25*mm, y, label)
        c.setFont('Helvetica', 9)
        c.drawString(80*mm, y, str(valeur))
        y -= 6*mm
    
    y -= 4*mm
    
    # Encadre PERIODE DU PRET (date de debut -> date de fin)
    c.setStrokeColor(COULEUR_PRIMAIRE)
    c.setLineWidth(1)
    c.setFillColor(HexColor('#eaf2f8'))
    c.rect(20*mm, y - 3*mm, largeur - 40*mm, 14*mm, fill=1, stroke=1)
    c.setFillColor(COULEUR_PRIMAIRE)
    c.setFont('Helvetica-Bold', 10)
    c.drawCentredString(largeur/2, y + 5*mm, 'PERIODE DU PRET')
    c.setFillColor(COULEUR_FONCE)
    c.setFont('Helvetica-Bold', 9)
    c.drawCentredString(largeur/2, y - 0.5*mm,
                        f'Date de debut : {date_debut_txt}    ->    '
                        f'Date de fin : {date_fin_txt}    ({pret.nombre_semaines} semaines)')
    
    y -= 20*mm
    
    # Encadre PRIX TOTAL (capital + gain Nyongo)
    c.setStrokeColor(COULEUR_SECONDAIRE)
    c.setLineWidth(2)
    c.setFillColor(HexColor('#eafaf1'))
    c.rect(20*mm, y - 5*mm, largeur - 40*mm, 20*mm, fill=1, stroke=1)
    c.setFillColor(COULEUR_FONCE)
    c.setFont('Helvetica-Bold', 13)
    c.drawCentredString(largeur/2, y + 8*mm, 
                       f'PRIX TOTAL A PAYER: {_formater_montant(pret.montant_avec_gain, pret.devise)}')
    c.setFont('Helvetica', 9)
    c.drawCentredString(largeur/2, y + 2.5*mm,
                       f'Capital {_formater_montant(pret.montant, pret.devise)}'
                       f'  +  Gain Nyongo {_formater_montant(pret.gain_total, pret.devise)}'
                       f'  =  {_formater_montant(pret.montant_avec_gain, pret.devise)}')
    c.setFont('Helvetica-Oblique', 8)
    if pret.type_gain == 'pourcentage':
        detail_gain = (f'Gain = {_formater_montant(pret.montant, pret.devise)} x {pret.taux_gain}%'
                       f' x {pret.nombre_semaines} semaines'
                       f' = {_formater_montant(pret.gain_total, pret.devise)}')
    else:
        detail_gain = (f'Gain = {_formater_montant(pret.montant_forfait, pret.devise)} (forfait/semaine)'
                       f' x {pret.nombre_semaines} semaines'
                       f' = {_formater_montant(pret.gain_total, pret.devise)}')
    c.drawCentredString(largeur/2, y - 2.5*mm, detail_gain)
    
    y -= 22*mm
    
    # Recapitulatif des paiements
    c.setFont('Helvetica-Bold', 10)
    c.drawString(20*mm, y, 'RECAPITULATIF DES PAIEMENTS')
    y -= 8*mm
    
    if pret.paiements:
        # En-tete tableau
        c.setFont('Helvetica-Bold', 8)
        colonnes = [20*mm, 50*mm, 75*mm, 100*mm, 130*mm]
        en_tetes = ['Date', 'Semaine', 'Montant', 'Devise', 'Note']
        
        c.setFillColor(COULEUR_PRIMAIRE)
        c.rect(20*mm, y - 1*mm, largeur - 40*mm, 7*mm, fill=1, stroke=0)
        c.setFillColor(white)
        for i, h in enumerate(en_tetes):
            c.drawString(colonnes[i], y, h)
        y -= 7*mm
        
        c.setFillColor(COULEUR_FONCE)
        c.setFont('Helvetica', 8)
        for paie in pret.paiements:
            if y < 30*mm:
                _dessiner_pied_page(c, largeur, hauteur, page_num)
                c.showPage()
                page_num += 1
                _dessiner_en_tete(c, largeur, hauteur, pret)
                y = hauteur - 35*mm
            
            c.drawString(colonnes[0], y, paie.date_paiement.strftime('%d/%m/%Y'))
            c.drawString(colonnes[1], y, str(paie.numero_semaine or '-'))
            c.drawString(colonnes[2], y, f"{paie.montant:,.2f}")
            c.drawString(colonnes[3], y, _symbole_devise(paie.devise))
            c.drawString(colonnes[4], y, (paie.note or '')[:25])
            y -= 6*mm
        
        # Total paye
        y -= 3*mm
        c.setFont('Helvetica-Bold', 9)
        c.drawString(25*mm, y, f'Total paye: {_formater_montant(pret.montant_total_rembourse, pret.devise)}')
        y -= 6*mm
        c.drawString(25*mm, y, f'Reste a payer: {_formater_montant(pret.montant_restant, pret.devise)}')
    else:
        c.setFont('Helvetica', 9)
        c.drawString(25*mm, y, 'Aucun paiement enregistre.')
    
    # Signatures
    y -= 20*mm
    c.setFont('Helvetica-Bold', 10)
    c.drawString(20*mm, y, 'SIGNATURES')
    y -= 10*mm
    
    # Deux colonnes de signatures
    c.setFont('Helvetica', 9)
    c.drawString(25*mm, y, 'Le Prestataire (Nyongo)')
    c.drawString(largeur/2 + 5*mm, y, 'L\'Emprunteur')
    y -= 20*mm
    c.line(20*mm, y, largeur/2 - 10*mm, y)
    c.line(largeur/2 + 5*mm, y, largeur - 20*mm, y)
    y -= 5*mm
    c.setFont('Helvetica', 8)
    c.drawString(20*mm, y, pret.client.nom)
    
    _dessiner_pied_page(c, largeur, hauteur, page_num)
    c.save()
    
    return pdf_path


def generer_tableau_amortissement_pdf(pret, app=None):
    """Generer le tableau d'amortissement en PDF"""
    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), 'data', 'pdfs')
    os.makedirs(output_dir, exist_ok=True)
    
    pdf_path = os.path.join(output_dir, f'amortissement_{pret.code_pret}.pdf')
    
    c = canvas.Canvas(pdf_path, pagesize=A4)
    largeur, hauteur = A4
    
    page_num = 1
    _dessiner_en_tete(c, largeur, hauteur, pret)
    
    y = hauteur - 35*mm
    
    # Titre
    c.setFillColor(COULEUR_PRIMAIRE)
    c.setFont('Helvetica-Bold', 14)
    c.drawString(20*mm, y, 'TABLEAU D\'AMORTISSEMENT')
    y -= 10*mm
    
    # Resume du pret
    c.setFillColor(COULEUR_FONCE)
    c.setFont('Helvetica-Bold', 9)
    resume = [
        ('Client:', pret.client.nom),
        ('Date de debut:', pret.date_debut.strftime('%d/%m/%Y') if pret.date_debut else 'N/A'),
        ('Date de fin:', pret.date_fin.strftime('%d/%m/%Y') if pret.date_fin else 'N/A'),
        ('Duree:', f'{pret.nombre_semaines} semaines'),
        ('Montant du pret:', _formater_montant(pret.montant, pret.devise)),
        ('Gain par semaine:', _formater_montant(pret.gain_hebdomadaire, pret.devise)),
        (f'Gain Nyongo total ({pret.nombre_semaines} sem.):',
         _formater_montant(pret.gain_total, pret.devise)),
        ('PRIX TOTAL (capital + gain):', _formater_montant(pret.montant_avec_gain, pret.devise)),
        ('Echeance hebdomadaire:', _formater_montant(pret.echeance_hebdomadaire, pret.devise)),
    ]
    if pret.type_gain == 'pourcentage':
        resume.insert(5, ('Taux:', f'{pret.taux_gain}% par semaine (x {pret.nombre_semaines} semaines)'))
    else:
        resume.insert(5, ('Type gain:', f'Forfait par semaine (x {pret.nombre_semaines} semaines)'))
    
    for label, val in resume:
        c.setFont('Helvetica-Bold', 9)
        c.drawString(25*mm, y, label)
        c.setFont('Helvetica', 9)
        c.drawString(90*mm, y, str(val))
        y -= 6*mm
    
    y -= 5*mm
    
    # Tableau amortissement
    c.setFont('Helvetica-Bold', 10)
    c.drawString(20*mm, y, 'ECHEANCIER HEBDOMADAIRE')
    y -= 8*mm
    
    echeance = pret.echeance_hebdomadaire
    montant_total_avec_gain = pret.montant_avec_gain
    
    # Colonnes du tableau
    col_positions = [15*mm, 35*mm, 60*mm, 85*mm, 115*mm, 145*mm]
    col_headers = ['Sem.', 'Date', 'Montant', 'Cumul', 'Reste', 'Statut']
    
    # En-tete du tableau
    c.setFillColor(COULEUR_PRIMAIRE)
    c.rect(15*mm, y - 1*mm, largeur - 30*mm, 8*mm, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont('Helvetica-Bold', 8)
    for i, h in enumerate(col_headers):
        c.drawString(col_positions[i], y + 1*mm, h)
    y -= 9*mm
    
    cumul = 0.0
    for sem in range(1, pret.nombre_semaines + 1):
        if y < 25*mm:
            _dessiner_pied_page(c, largeur, hauteur, page_num)
            c.showPage()
            page_num += 1
            _dessiner_en_tete(c, largeur, hauteur, pret)
            y = hauteur - 35*mm
            
            # Re-en-tete tableau
            c.setFillColor(COULEUR_PRIMAIRE)
            c.rect(15*mm, y - 1*mm, largeur - 30*mm, 8*mm, fill=1, stroke=0)
            c.setFillColor(white)
            c.setFont('Helvetica-Bold', 8)
            for i, h in enumerate(col_headers):
                c.drawString(col_positions[i], y + 1*mm, h)
            y -= 9*mm
        
        date_echeance = pret.date_echeance_semaine(sem)
        cumul += echeance
        reste = max(0, montant_total_avec_gain - cumul)
        
        # Verifier si paiement existe pour cette semaine
        paiement_semaine = None
        for paie in pret.paiements:
            if paie.numero_semaine == sem:
                paiement_semaine = paie
                break
        
        statut = 'Paye' if paiement_semaine else 'En attente'
        
        # Alterner les couleurs
        if sem % 2 == 0:
            c.setFillColor(COULEUR_CLAIR)
            c.rect(15*mm, y - 2*mm, largeur - 30*mm, 7*mm, fill=1, stroke=0)
        
        c.setFillColor(COULEUR_FONCE)
        c.setFont('Helvetica', 8)
        c.drawString(col_positions[0], y, str(sem))
        c.drawString(col_positions[1], y, date_echeance.strftime('%d/%m/%Y'))
        c.drawString(col_positions[2], y, _formater_montant(echeance, pret.devise))
        c.drawString(col_positions[3], y, _formater_montant(cumul, pret.devise))
        c.drawString(col_positions[4], y, _formater_montant(reste, pret.devise))
        
        if statut == 'Paye':
            c.setFillColor(COULEUR_SECONDAIRE)
        else:
            c.setFillColor(COULEUR_ACCENT)
        c.setFont('Helvetica-Bold', 8)
        c.drawString(col_positions[5], y, statut)
        
        y -= 7*mm
    
    # Ligne totale
    y -= 3*mm
    c.setFillColor(COULEUR_PRIMAIRE)
    c.rect(15*mm, y - 2*mm, largeur - 30*mm, 8*mm, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont('Helvetica-Bold', 9)
    c.drawString(col_positions[0], y, 'TOTAL')
    c.drawString(col_positions[2], y, _formater_montant(montant_total_avec_gain, pret.devise))
    c.drawString(col_positions[4], y, _formater_montant(0, pret.devise))
    
    _dessiner_pied_page(c, largeur, hauteur, page_num)
    c.save()
    
    return pdf_path


