import os
from flask import Flask
from app.config import Config, DB_PATH, UPLOAD_FOLDER
from app.models import db, Utilisateur, Client, Pret, Paiement
from werkzeug.security import generate_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from datetime import datetime


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Derriere le serveur de l'hebergeur (https), respecter les en-tetes du proxy
    if app.config.get('IS_HOSTED'):
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
        if app.config['SECRET_KEY'] == 'nyongo-secret-key-change-in-production':
            print("[Nyongo][ATTENTION] SECRET_KEY par defaut en ligne : "
                  "definissez la variable SECRET_KEY chez votre hebergeur.")

    # S'assurer que les dossiers de donnees existent (1er demarrage)
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    # Initialiser la base de donnees
    db.init_app(app)
    
    # Enregistrer les routes
    from app.routes import enregistrer_routes
    enregistrer_routes(app)
    
    # Template filter: format_montant
    @app.template_filter('format_montant')
    def format_montant_filter(montant, devise='USD'):
        if montant is None:
            return '0.00'
        symbole = '$' if devise == 'USD' else 'FC'
        return f"{montant:,.2f} {symbole}"
    
    # Template filter: min (pour eviter les conflits)
    @app.template_filter('min')
    def min_filter(a, b):
        return min(a, b)
    
    # Template global: now
    app.jinja_env.globals['now'] = datetime.now
    
    # Creer les tables et l'utilisateur par defaut
    with app.app_context():
        db.create_all()
        
        # Creer l'utilisateur admin par defaut si il n'existe pas
        identifiant = app.config['ADMIN_USERNAME']
        mot_de_passe = app.config['ADMIN_PASSWORD']
        if not Utilisateur.query.filter_by(nom_utilisateur=identifiant).first():
            admin = Utilisateur(
                nom_utilisateur=identifiant,
                mot_de_passe=generate_password_hash(mot_de_passe),
                nom_complet='Administrateur',
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            print(f"[Nyongo] Utilisateur par defaut cree: {identifiant}")
            if mot_de_passe == 'admin123' and app.config.get('IS_HOSTED'):
                print("[Nyongo][ATTENTION] Mot de passe admin par defaut en ligne : "
                      "definissez la variable ADMIN_PASSWORD chez votre hebergeur.")
        
        print("[Nyongo] Base de donnees initialisee avec succes.")
    
    return app
