import os
import uuid
from datetime import datetime, date, timedelta
from flask_sqlalchemy import SQLAlchemy
from flask import current_app

db = SQLAlchemy()


class Client(db.Model):
    """Modele Client"""
    __tablename__ = 'clients'
    
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(150), nullable=False)
    telephone = db.Column(db.String(30), nullable=True)
    adresse = db.Column(db.String(255), nullable=True)
    numero_piece = db.Column(db.String(50), nullable=True)
    type_piece = db.Column(db.String(50), default='Carte d\'identite')
    photo = db.Column(db.String(255), nullable=True)
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)
    
    prets = db.relationship('Pret', backref='client', lazy=True)
    
    def __repr__(self):
        return f'<Client {self.nom}>'


class Pret(db.Model):
    """Modele Pret - Convention de pret Nyongo"""
    __tablename__ = 'prets'
    
    id = db.Column(db.Integer, primary_key=True)
    code_pret = db.Column(db.String(50), unique=True, nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)
    montant = db.Column(db.Float, nullable=False)
    devise = db.Column(db.String(10), default='USD')
    nombre_semaines = db.Column(db.Integer, default=12)
    date_pret = db.Column(db.Date, default=date.today)
    statut = db.Column(db.String(30), default='En cours')
    
    # Gain Nyongo
    type_gain = db.Column(db.String(20), default='pourcentage')  # 'pourcentage' ou 'forfait'
    taux_gain = db.Column(db.Float, default=10.0)  # Pourcentage (ex: 10 = 10%)
    montant_forfait = db.Column(db.Float, default=0.0)  # Montant fixe si forfait
    
    note = db.Column(db.Text, nullable=True)
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)
    
    paiements = db.relationship('Paiement', backref='pret', lazy=True,
                                 cascade='all, delete-orphan')
    
    @property
    def gain_hebdomadaire(self):
        """Gain Nyongo pour UNE semaine.

        - type_gain='pourcentage' : montant x (taux_gain / 100) par semaine
        - type_gain='forfait'     : montant_forfait par semaine
        """
        if self.type_gain == 'pourcentage':
            return float(self.montant) * (self.taux_gain / 100.0)
        return float(self.montant_forfait)

    @property
    def gain_total(self):
        """Calcul du gain Nyongo TOTAL sur toute la duree du pret.

        CONVENTION :
        Le gain est calcule PAR SEMAINE puis multiplie par le nombre de semaines.
        - type_gain='pourcentage' : gain = montant x (taux_gain / 100) x nombre_semaines
          Ex: pret 1000$ a 10% sur 12 semaines -> 100$ x 12 = 1200$
        - type_gain='forfait' : gain = montant_forfait x nombre_semaines
          Ex: forfait 20$ sur 12 semaines -> 240$
        """
        semaines = self.nombre_semaines or 0
        return self.gain_hebdomadaire * semaines
    
    @property
    def montant_avec_gain(self):
        """Montant Total = montant du pret + gain Nyongo.
        C'est ce montant qui est affiche PARTOUT comme 'Montant Total' dans l'application."""
        return float(self.montant) + self.gain_total
    
    @property
    def date_debut(self):
        """Date de debut du pret (= date d'octroi du pret)."""
        return self.date_pret

    @property
    def date_fin(self):
        """Date de fin du pret = date de debut + nombre de semaines defini manuellement.

        Ex: debut 01/03/2026 avec 8 semaines -> fin 26/04/2026
        """
        if not self.date_pret:
            return None
        semaines = self.nombre_semaines or 0
        return self.date_pret + timedelta(weeks=semaines)

    @property
    def duree_texte(self):
        """Duree lisible : '8 semaines (du 01/03/2026 au 26/04/2026)'"""
        if self.date_debut and self.date_fin:
            return (f"{self.nombre_semaines} semaines "
                    f"(du {self.date_debut.strftime('%d/%m/%Y')} "
                    f"au {self.date_fin.strftime('%d/%m/%Y')})")
        return f"{self.nombre_semaines} semaines"

    def date_echeance_semaine(self, numero_semaine):
        """Date d'echeance d'une semaine donnee (1 = premiere semaine)."""
        if not self.date_pret:
            return None
        return self.date_pret + timedelta(weeks=numero_semaine)

    @property
    def montant_total_rembourse(self):
        """Somme totale effectivement payee"""
        return sum(p.montant for p in self.paiements)
    
    @property
    def montant_restant(self):
        """Montant restant a payer = montant_avec_gain - montant deja paye"""
        return self.montant_avec_gain - self.montant_total_rembourse
    
    @property
    def echeance_hebdomadaire(self):
        """Montant a payer par semaine (base sur le montant total avec gain)"""
        if self.nombre_semaines and self.nombre_semaines > 0:
            return self.montant_avec_gain / self.nombre_semaines
        return 0
    
    @property
    def derniere_date_paiement(self):
        dernier = None
        for p in self.paiements:
            if dernier is None or p.date_paiement > dernier:
                dernier = p.date_paiement
        return dernier
    
    @staticmethod
    def generer_code():
        """Generer un code de pret unique au format NYO-YYYYMMDD-XXXX"""
        aujourd_hui = date.today()
        prefix = f"NYO-{aujourd_hui.strftime('%Y%m%d')}"
        suffix = str(uuid.uuid4())[:4].upper()
        return f"{prefix}-{suffix}"
    
    def __repr__(self):
        return f'<Pret {self.code_pret} - {self.montant} {self.devise}>'


class Paiement(db.Model):
    """Modele Paiement"""
    __tablename__ = 'paiements'
    
    id = db.Column(db.Integer, primary_key=True)
    pret_id = db.Column(db.Integer, db.ForeignKey('prets.id'), nullable=False)
    montant = db.Column(db.Float, nullable=False)
    devise = db.Column(db.String(10), default='USD')
    date_paiement = db.Column(db.Date, default=date.today)
    numero_semaine = db.Column(db.Integer, nullable=True)
    note = db.Column(db.Text, nullable=True)
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Paiement {self.montant} {self.devise}>'


class Utilisateur(db.Model):
    """Modele Utilisateur pour l'authentification"""
    __tablename__ = 'utilisateurs'
    
    id = db.Column(db.Integer, primary_key=True)
    nom_utilisateur = db.Column(db.String(80), unique=True, nullable=False)
    mot_de_passe = db.Column(db.String(255), nullable=False)
    nom_complet = db.Column(db.String(150), nullable=True)
    role = db.Column(db.String(30), default='admin')
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)
