import os

BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))


def _database_uri():
    """URL de la base de donnees.

    - En local (hors ligne) : fichier SQLite dans le dossier data/
    - En ligne (hebergement) : variable d'environnement DATABASE_URL
      (PostgreSQL fourni par l'hebergeur) pour que les donnees soient
      conservees de facon permanente.
    """
    url = os.environ.get('DATABASE_URL', '').strip()
    if url:
        # Certains hebergeurs fournissent encore l'ancien prefixe postgres://
        if url.startswith('postgres://'):
            url = url.replace('postgres://', 'postgresql://', 1)
        return url
    return 'sqlite:///' + os.path.join(BASE_DIR, 'data', 'pret_particuliers.db')


class Config:
    """Configuration de l'application Nyongo"""
    SQLALCHEMY_DATABASE_URI = _database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {'pool_pre_ping': True}
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'data', 'uploads')
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
    DEFAUT_NOMBRE_SEMAINES = 12
    DEFAUT_TAUX_GAIN = 10.0  # 10% par defaut
    SECRET_KEY = os.environ.get('SECRET_KEY', 'nyongo-secret-key-change-in-production')

    # Mot de passe du compte admin cree au premier demarrage.
    # En ligne : definir ADMIN_PASSWORD dans les variables d'environnement.
    ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'admin')
    ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin123')

    # Mode hebergement : active les protections adaptees a Internet
    IS_HOSTED = bool(os.environ.get('DATABASE_URL') or os.environ.get('PORT'))
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_COOKIE_SECURE = IS_HOSTED


# Constantes reste accessibles si importees directement
DB_PATH = os.path.join(BASE_DIR, 'data', 'pret_particuliers.db')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'data', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
DEFAUT_NOMBRE_SEMAINES = 12
DEFAUT_TAUX_GAIN = 10.0
