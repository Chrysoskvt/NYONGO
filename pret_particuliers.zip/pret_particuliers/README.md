# NYONGO - Application de Pret entre Particuliers (RDC)

## Description
Application de gestion de prets P2P (peer-to-peer) pour la Republique Democratique du Congo.
Gestion des clients, prets, paiements et generation de factures PDF.

**Double devise:** USD ($) et CDF (FC)

## Duree du pret : uniquement en SEMAINES

La duree d'un pret est exprimee **exclusivement en semaines** (jamais en mois).
Dans le formulaire, le champ **"Duree du pret (semaines)"** est vide par defaut :
vous tapez vous-meme le nombre de semaines souhaite (1, 2, 3, 7, 12, 30, 52...).
Aucune valeur n'est imposee et il n'y a pas de liste a choix.

- Le champ est obligatoire : un pret sans duree en semaines est refuse.
- Date de fin = date de debut + (nombre de semaines x 7 jours), calculee automatiquement.
- Le tableau d'amortissement contient exactement une ligne par semaine saisie.

## Convention de calcul Gain Nyongo

Le gain Nyongo se calcule PAR SEMAINE puis est MULTIPLIE par le nombre de semaines :
- **Mode Pourcentage** : gain par semaine = montant_pret × (taux / 100), puis gain total = gain par semaine × nombre_semaines
- **Mode Forfait** : gain par semaine = montant_forfait, puis gain total = montant_forfait × nombre_semaines
- **Prix Total** = montant_pret + gain Nyongo total
- **Echeance hebdomadaire** = Prix Total / nombre_semaines

### Exemple
- Pret de 1000$ a 10% sur 12 semaines
- Gain par semaine = 1000 × 10% = **100$**
- Gain Nyongo total = 100 × 12 = **1200$**
- Prix Total = 1000 + 1200 = **2200$**
- Echeance = 2200 / 12 = **183.33$/semaine**

## Installation

### Avec connexion internet
```bash
pip install -r requirements.txt
python run.py
```

### Sans connexion internet (hors ligne)
1. Placez les fichiers `.whl` dans le dossier `packages/`
2. Lancez `python scripts/install_offline.py`
3. Puis `python run.py`

## Premier demarrage
- Ouvrez http://127.0.0.1:5000
- Login par defaut : **admin** / **admin123**
- Changez le mot de passe apres la premiere connexion

## Mise en ligne (hebergement Internet)
L'application peut aussi etre hebergee en ligne (adresse https accessible
depuis n'importe quel telephone). Voir le guide detaille **HEBERGEMENT.md**.
En resume : depot GitHub prive -> Render (Blueprint) -> base PostgreSQL
creee automatiquement -> mot de passe admin defini par variable
d'environnement `ADMIN_PASSWORD`.

Le mode local hors ligne n'est pas modifie : `python run.py` fonctionne
comme avant, avec la base SQLite du dossier `data/`.

## Structure du projet
```
pret_particuliers/
  run.py                  # Point d'entree local (hors ligne)
  wsgi.py                 # Point d'entree serveur en ligne (gunicorn)
  Procfile                # Commande de demarrage en ligne
  render.yaml             # Deploiement automatique sur Render
  runtime.txt             # Version de Python pour l'hebergeur
  requirements.txt        # Dependances Python (local)
  requirements-prod.txt   # Dependances Python (en ligne)
  README.md               # Ce fichier
  HEBERGEMENT.md          # Guide de mise en ligne
  packages/               # Packages .whl pour installation offline
  scripts/
    install_offline.py    # Script d'installation hors ligne
  app/
    __init__.py
    config.py             # Configuration Flask + DB
    main.py               # Factory Flask + init DB
    models.py             # Modeles (User, Client, Pret, Paiement)
    routes.py             # Routes et logique metier
    utils/
      __init__.py
      pdf_generator.py     # Generation factures et amortissement PDF
    templates/
      base.html
      login.html
      index.html
      clients.html
      client_form.html
      client_detail.html
      loans.html
      loan_form.html
      loan_detail.html
      paiement_form.html
```

## Fonctionnalites
- Authentification utilisateur
- Gestion des clients (CRUD)
- Gestion des prets avec calcul automatique du gain Nyongo
- Suivi des paiements hebdomadaires
- Generation de factures PDF
- Tableau d'amortissement PDF
- Dashboard avec statistiques
- Double devise USD / CDF

## Compatibilite
- Python 3.12
- Windows / Linux
- Fonctionne 100% hors ligne
