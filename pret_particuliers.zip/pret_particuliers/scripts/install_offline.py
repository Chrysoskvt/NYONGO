"""
Script d'installation hors ligne des packages Python necessaires.
Utilisation: python scripts/install_offline.py

Ce script installe les packages depuis le dossier 'packages/' 
sans connexion internet.
"""
import subprocess
import sys
import os
from pathlib import Path

PACKAGES_DIR = Path(__file__).parent.parent / 'packages'
REQUIREMENTS = Path(__file__).parent.parent / 'requirements.txt'


def install_offline():
    """Installer les packages Python depuis le dossier packages/ hors ligne."""
    print("=" * 60)
    print("  NYONGO - Installation hors ligne des packages")
    print("=" * 60)
    
    if not PACKAGES_DIR.exists():
        print(f"[ERREUR] Dossier '{PACKAGES_DIR}' introuvable.")
        print("  Veuillez placer les fichiers .whl dans le dossier packages/")
        print("  Telechargez-les sur https://pypi.org/ avec connexion,")
        print("  puis copiez-les sur la machine sans internet.")
        sys.exit(1)
    
    whl_files = list(PACKAGES_DIR.glob('*.whl')) + list(PACKAGES_DIR.glob('*.tar.gz'))
    
    if not whl_files:
        print(f"[ERREUR] Aucun fichier .whl ou .tar.gz dans '{PACKAGES_DIR}'")
        sys.exit(1)
    
    print(f"\n[INFO] {len(whl_files)} package(s) trouve(s) dans packages/")
    for f in whl_files:
        print(f"  - {f.name}")
    
    # Installer chaque package
    for whl in whl_files:
        print(f"\n[INSTALL] {whl.name}...")
        result = subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '--no-deps', '--no-index',
             '--find-links', str(PACKAGES_DIR), str(whl)],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            print(f"  [OK] {whl.name} installe avec succes")
        else:
            print(f"  [ECHEC] {whl.name}")
            print(f"  Erreur: {result.stderr}")
    
    # Puis installer avec dependances dans l'ordre
    print("\n[INFO] Resolution des dependances...")
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'install', '--no-index',
         '--find-links', str(PACKAGES_DIR), '-r', str(REQUIREMENTS)],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print("  [OK] Tous les packages installes avec succes!")
    else:
        print("  [ATTENTION] Certains packages peuvent manquer.")
        print(f"  {result.stderr}")
    
    # Verifier les installations
    print("\n[VERIFICATION]")
    packages = ['flask', 'flask_sqlalchemy', 'sqlalchemy', 'werkzeug', 'reportlab', 'colorama']
    for pkg in packages:
        try:
            __import__(pkg)
            print(f"  [OK] {pkg}")
        except ImportError:
            print(f"  [MANQUANT] {pkg}")
    
    print("\n" + "=" * 60)
    print("  Installation terminee.")
    print("  Pour lancer l'application: python run.py")
    print("=" * 60)


if __name__ == '__main__':
    install_offline()
