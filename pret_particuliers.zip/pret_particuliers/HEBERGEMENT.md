# Mettre Nyongo en ligne (hebergement)

Ce guide explique comment publier l'application sur Internet pour y acceder
depuis n'importe quel telephone ou ordinateur, avec une adresse en https.

L'application continue de fonctionner **exactement comme avant en local**
(hors ligne, avec `python run.py`). L'hebergement est un mode en plus.

---

## 1. Ce qui a ete ajoute pour l'hebergement

| Fichier | Role |
|---|---|
| `wsgi.py` | Point d'entree utilise par le serveur en ligne |
| `Procfile` | Commande de demarrage (gunicorn) |
| `render.yaml` | Deploiement automatique sur Render, base de donnees incluse |
| `requirements-prod.txt` | Dependances pour le serveur en ligne |
| `runtime.txt` | Version de Python (3.12) |
| `.gitignore` | Evite d'envoyer la base locale et les fichiers inutiles sur GitHub |

L'application detecte automatiquement le mode :

- **En local** : base de donnees SQLite dans le dossier `data/`
- **En ligne** : base PostgreSQL fournie par l'hebergeur (variable `DATABASE_URL`)

---

## 2. Methode recommandee : Render (gratuit pour demarrer)

### Etape 1 — Mettre le code sur GitHub

1. Creez un compte sur https://github.com (gratuit).
2. Cliquez sur **New repository**, nommez-le `nyongo`, choisissez **Private**
   (important : votre code reste prive), puis **Create repository**.
3. Envoyez les fichiers. Le plus simple sans ligne de commande :
   sur la page du depot, cliquez **uploading an existing file**, puis
   glissez-deposez le contenu du dossier `pret_particuliers`
   (tous les fichiers et dossiers : `app/`, `scripts/`, `wsgi.py`,
   `Procfile`, `render.yaml`, `requirements-prod.txt`, etc.).
   N'envoyez pas le dossier `data/` s'il existe.

   Avec Git en ligne de commande :

   ```bash
   cd pret_particuliers
   git init
   git add .
   git commit -m "Application Nyongo"
   git branch -M main
   git remote add origin https://github.com/VOTRE-NOM/nyongo.git
   git push -u origin main
   ```

### Etape 2 — Creer le service sur Render

1. Creez un compte sur https://render.com et connectez-vous avec GitHub.
2. Cliquez **New +** puis **Blueprint** (Render lit alors `render.yaml`
   et cree tout seul le site **et** la base de donnees).
3. Selectionnez votre depot `nyongo`, puis **Apply**.
4. Render demande la valeur de `ADMIN_PASSWORD` : saisissez un **mot de passe
   fort** (voir la section Securite plus bas). C'est le mot de passe de
   connexion a l'application.
5. Attendez 3 a 5 minutes : le premier deploiement se termine et Render affiche
   une adresse du type `https://nyongo.onrender.com`.

> Si vous ne voyez pas l'option Blueprint : choisissez **New + > Web Service**,
> selectionnez le depot, puis renseignez a la main
> Build Command = `pip install -r requirements-prod.txt` et
> Start Command = `gunicorn wsgi:app --bind 0.0.0.0:$PORT`.
> Creez ensuite une base **PostgreSQL** (New + > Postgres) et copiez son
> "Internal Database URL" dans une variable d'environnement `DATABASE_URL`
> du service web.

### Etape 3 — Premiere connexion

1. Ouvrez l'adresse fournie par Render.
2. Connectez-vous avec `admin` et le mot de passe que vous avez saisi
   a l'etape 2 (et non `admin123`).
3. Creez vos clients et vos prets : tout est enregistre dans la base en ligne.

### Mises a jour plus tard

Chaque fois que vous modifiez le code et l'envoyez sur GitHub, Render
redeploie automatiquement la nouvelle version. Vos donnees ne sont pas effacees.

---

## 3. Variables d'environnement a definir en ligne

| Variable | Obligatoire | Role |
|---|---|---|
| `ADMIN_PASSWORD` | Oui | Mot de passe du compte admin cree au 1er demarrage |
| `SECRET_KEY` | Oui | Cle de securite des sessions (Render la genere seule) |
| `DATABASE_URL` | Oui | Base PostgreSQL (fournie par l'hebergeur) |
| `ADMIN_USERNAME` | Non | Nom du compte admin (par defaut `admin`) |

Attention : `ADMIN_PASSWORD` sert uniquement a **creer** le compte au premier
demarrage. Si vous la changez apres coup, le mot de passe deja enregistre en
base ne change pas.

---

## 4. Securite : a lire avant la mise en ligne

Des que l'application est publique, la page de connexion est accessible a
tout le monde sur Internet. Trois regles :

1. **Ne laissez jamais `admin123`.** Mettez un mot de passe long
   (12 caracteres minimum, melange de lettres, chiffres et symboles).
2. **Ne mettez pas de mot de passe dans le code ni sur GitHub.** Utilisez
   uniquement les variables d'environnement de l'hebergeur.
3. **Gardez le depot GitHub en prive.**

A prevoir plus tard si l'application accueille plusieurs utilisateurs :
blocage temporaire apres plusieurs echecs de connexion, et journal des acces.

---

## 5. Sauvegardes

Les donnees de prets sont precieuses. Sur Render, dans la page de la base de
donnees, utilisez **Backups** (ou le bouton de telechargement) pour recuperer
une copie reguliere. Sur l'offre gratuite, faites une sauvegarde manuelle
chaque semaine.

A savoir sur les offres gratuites : la base PostgreSQL gratuite de Render
expire au bout de 30 jours et le site s'endort apres 15 minutes sans visite
(le premier chargement suivant prend environ 30 secondes). Pour un usage
professionnel reel, passez a l'offre payante la plus basse
(environ 7 $/mois pour le site + 7 $/mois pour la base).

---

## 6. Autres hebergeurs possibles

**Railway** (https://railway.app) — meme principe : connectez GitHub, ajoutez
une base PostgreSQL, Railway detecte le `Procfile`. Environ 5 $/mois d'usage.

**PythonAnywhere** (https://pythonanywhere.com) — interface simple, environ
5 $/mois, stockage permanent. La base SQLite du dossier `data/` suffit ici :
ne definissez pas `DATABASE_URL`. Configurez le fichier WSGI du site pour
qu'il importe `app` depuis `wsgi.py`.

**VPS** (Hetzner, Contabo, DigitalOcean, 4 a 6 $/mois) — plus de liberte mais
vous gerez tout : Python, gunicorn, Nginx en frontal, certificat https avec
Certbot, et un service systemd pour le demarrage automatique.

---

## 7. Verifier en local avant de publier

Pour tester le mode "production" sur votre ordinateur :

```bash
pip install -r requirements-prod.txt
gunicorn wsgi:app --bind 127.0.0.1:8000
```

Sous Windows, gunicorn ne fonctionne pas : continuez avec `python run.py`
pour les tests locaux, le mode en ligne sera assure par l'hebergeur (Linux).
