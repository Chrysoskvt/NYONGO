import os
from flask import Flask
from app.config import Config, DB_PATH, UPLOAD_FOLDER
from app.models import db, Utilisateur, Client, Pret, Paiement
from werkzeug.security import generate_password_hash
from datetime import datetime


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # S'assurer que les dossiers de donnees existent (1er demarrage)
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    # Initialiser la base de donnees
    db.init_app(app)
    
    # Enregistrer les routes
    from app.routes import enregistrer_routes
    enregistrer_routes(app)
    
    # Template filter: format_montant
    @app.template_filter('format_montant')
    def format_montant_filter(montant, devise='USD'):
        if montant is None:
            return '0.00'
        symbole = '$' if devise == 'USD' else 'FC'
        return f"{montant:,.2f} {symbole}"
    
    # Template filter: min (pour eviter les conflits)
    @app.template_filter('min')
    def min_filter(a, b):
        return min(a, b)
    
    # Template global: now
    app.jinja_env.globals['now'] = datetime.now
    
    # Creer les tables et l'utilisateur par defaut
    with app.app_context():
        db.create_all()
        
        # Creer l'utilisateur admin par defaut si il n'existe pas
        if not Utilisateur.query.filter_by(nom_utilisateur='admin').first():
            admin = Utilisateur(
                nom_utilisateur='admin',
                mot_de_passe=generate_password_hash('admin123'),
                nom_complet='Administrateur',
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            print("[Nyongo] Utilisateur par defaut cree: admin / admin123")
        
        print("[Nyongo] Base de donnees initialisee avec succes.")
    
    return app
