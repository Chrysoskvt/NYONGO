import os

BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))


class Config:
    """Configuration de l'application Nyongo"""
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(BASE_DIR, 'data', 'pret_particuliers.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'data', 'uploads')
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
    DEFAUT_NOMBRE_SEMAINES = 12
    DEFAUT_TAUX_GAIN = 10.0  # 10% par defaut
    SECRET_KEY = os.environ.get('SECRET_KEY', 'nyongo-secret-key-change-in-production')


# Constantes reste accessibles si importees directement
DB_PATH = os.path.join(BASE_DIR, 'data', 'pret_particuliers.db')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'data', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
DEFAUT_NOMBRE_SEMAINES = 12
DEFAUT_TAUX_GAIN = 10.0